import 'dotenv/config';
import http from 'node:http';
import { transcripts } from '../src/data/transcripts';
import { citationFromSegment } from '../src/lib/citations';
import { GeminiEmbeddingProvider, DeterministicEmbeddingProvider } from '../src/lib/embeddings';
import { GeminiProvider, NOT_FOUND, validateAnalysis, validateModelAnswer } from '../src/lib/llm';
import { parseAll } from '../src/lib/parser';
import { buildVectorIndex, type SegmentFilter } from '../src/lib/retrieval';
import type { TranscriptSegment } from '../src/types';

const port = Number(process.env.API_PORT ?? 8787);
const segments = parseAll(transcripts);
const modelName = process.env.GEMINI_MODEL ?? 'gemini-3.5-flash-lite';
const embeddingModelName = process.env.GEMINI_EMBEDDING_MODEL ?? 'gemini-embedding-001';
const embeddingProvider = process.env.GEMINI_API_KEY
  ? new GeminiEmbeddingProvider(process.env.GEMINI_API_KEY, embeddingModelName)
  : new DeterministicEmbeddingProvider();
const llm = process.env.GEMINI_API_KEY ? new GeminiProvider(process.env.GEMINI_API_KEY, modelName) : undefined;
const indexPromise = buildVectorIndex(segments, embeddingProvider);

function json(response: http.ServerResponse, status: number, body: unknown): void {
  response.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'access-control-allow-origin': '*' });
  response.end(JSON.stringify(body));
}

function citationsFor(ids: string[], sourceSegments: TranscriptSegment[]) {
  const byId = new Map(sourceSegments.map((segment) => [segment.id, segment]));
  return [...new Set(ids)].map((id) => {
    const segment = byId.get(id);
    return segment ? citationFromSegment(segment) : null;
  }).filter((citation) => citation !== null);
}

function fallbackAnswer(question: string, evidence: TranscriptSegment[]) {
  if (evidence.length === 0) return { answer: NOT_FOUND, segmentIds: [] };
  return { answer: `Based on these interviews, the retrieved evidence addresses this question across ${new Set(evidence.map((segment) => segment.market)).size} market(s).`, segmentIds: evidence.slice(0, 4).map((segment) => segment.id) };
}

async function groundedAnswer(question: string, filter?: SegmentFilter) {
  const index = await indexPromise;
  const evidence = await index.search(question, embeddingProvider, 8, filter);
  if (evidence.length === 0) return { answer: NOT_FOUND, citations: [], confidence: 'none', retrievedCount: 0 };
  const modelAnswer = llm ? await llm.answer(question, evidence) : fallbackAnswer(question, evidence);
  const validated = validateModelAnswer(modelAnswer, evidence);
  return { answer: validated.answer, citations: citationsFor(validated.segmentIds, segments), confidence: validated.segmentIds.length ? (llm ? 'high' : 'medium') : 'none', retrievedCount: evidence.length };
}

async function handle(pathname: string, payload: Record<string, unknown>) {
  if (pathname === '/api/ask') return groundedAnswer(String(payload.question ?? ''));
  if (pathname === '/api/guide') return groundedAnswer(String(payload.question ?? ''), { documentId: String(payload.documentId ?? '') });
  if (pathname === '/api/analysis') {
    const index = await indexPromise;
    const evidence = await index.search('adoption barriers budgets ROI training clinical outcomes outlook purchasing timeline', embeddingProvider, 18);
    const items = llm ? validateAnalysis(await llm.analysis(evidence), segments) : [];
    return { items: items.map((item) => ({ ...item, citations: citationsFor(item.segmentIds, segments) })), retrievedCount: evidence.length };
  }
  if (pathname === '/api/health') return { status: 'ok', semanticEmbeddings: Boolean(process.env.GEMINI_API_KEY), llm: Boolean(llm), model: llm?.modelName ?? null, embeddingModel: embeddingProvider instanceof GeminiEmbeddingProvider ? embeddingProvider.modelName : null, segmentCount: segments.length };
  return null;
}

const server = http.createServer((request, response) => {
  if (request.method === 'OPTIONS') return json(response, 204, {});
  const url = new URL(request.url ?? '/', `http://localhost:${port}`);
  if (request.method === 'GET' && url.pathname === '/api/health') return handle('/api/health', {}).then((body) => json(response, 200, body));
  if (request.method !== 'POST') return json(response, 404, { error: 'Not found' });
  let body = '';
  request.on('data', (chunk) => { body += chunk; });
  request.on('end', async () => {
    try {
      const result = await handle(url.pathname, JSON.parse(body || '{}'));
      if (!result) return json(response, 404, { error: 'Not found' });
      return json(response, 200, result);
    } catch (error) {
      console.error(error);
      return json(response, 500, { error: 'The grounded analysis request failed.' });
    }
  });
});

server.listen(port, () => console.log(`ExpertCall API listening on http://localhost:${port} (${llm ? 'Gemini' : 'no-key fallback'})`));
