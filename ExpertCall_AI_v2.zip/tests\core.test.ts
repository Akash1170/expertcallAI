import { describe, expect, it } from 'vitest';
import { transcripts } from '../src/data/transcripts';
import { citationFromSegment, verifyQuote } from '../src/lib/citations';
import { DeterministicEmbeddingProvider } from '../src/lib/embeddings';
import { NOT_FOUND, validateAnalysis, validateModelAnswer } from '../src/lib/llm';
import { parseAll, parseTranscript } from '../src/lib/parser';
import { buildVectorIndex, cosineSimilarity, retrieve } from '../src/lib/retrieval';

const segments = parseAll(transcripts);

describe('transcript ingestion', () => {
  it('parses timestamp, speaker, text and metadata', () => {
    const france = parseTranscript(transcripts[0]);
    expect(france).toHaveLength(14);
    expect(france[1]).toMatchObject({ timestamp: '00:18', speaker: 'Dr. Martin', market: 'France', expert: 'Dr. Jean Martin' });
    expect(france[1].seconds).toBe(18);
  });
  it('preserves all source documents and metadata', () => {
    expect(segments).toHaveLength(42);
    expect(new Set(segments.map((segment) => segment.documentId))).toEqual(new Set(['france-01', 'germany-02', 'uk-03']));
  });
});

describe('citation verification', () => {
  const segment = parseTranscript(transcripts[0])[1];
  it('accepts only verbatim source text', () => {
    expect(verifyQuote('Adoption is growing', segment)).toBe(true);
    expect(verifyQuote('Adoption is shrinking', segment)).toBe(false);
    expect(citationFromSegment(segment, 'invented')).toBe(null);
  });
});

describe('semantic retrieval utilities', () => {
  it('calculates cosine similarity', () => {
    expect(cosineSimilarity([1, 0], [1, 0])).toBe(1);
    expect(cosineSimilarity([1, 0], [0, 1])).toBe(0);
  });
  it('supports deterministic hybrid retrieval and metadata filtering', async () => {
    const index = await buildVectorIndex(segments, new DeterministicEmbeddingProvider());
    const results = await index.search('What are the barriers to adoption?', new DeterministicEmbeddingProvider(), 3, { market: 'Germany' });
    expect(results.length).toBeGreaterThan(0);
    expect(results.every((segment) => segment.market === 'Germany')).toBe(true);
    expect(results.every((segment) => segment.speaker !== 'Interviewer')).toBe(true);
  });
  it('retains lexical utility for deterministic evaluation', () => expect(retrieve('barriers training', segments).length).toBeGreaterThan(0));
  it('does not treat generic shared words as evidence for an unrelated question', async () => {
    const index = await buildVectorIndex(segments, new DeterministicEmbeddingProvider());
    expect(await index.search('What reimbursement tax policy does the EU use for robotic surgery?', new DeterministicEmbeddingProvider())).toHaveLength(0);
  });
});

describe('model output validation', () => {
  it('rejects unknown segment IDs and derives not-found when no IDs remain', () => {
    expect(validateModelAnswer({ answer: 'unsupported', segmentIds: ['made-up-id'] }, segments)).toEqual({ answer: NOT_FOUND, segmentIds: [] });
  });
  it('filters unsupported analysis citations', () => {
    const valid = validateAnalysis([{ type: 'agreement', title: 'Theme', synthesis: 'Evidence', segmentIds: [segments[1].id, 'fake'] }], segments);
    expect(valid[0].segmentIds).toEqual([segments[1].id]);
  });
});
