import { GoogleGenAI } from '@google/genai';
import type { TranscriptSegment } from '../types';

export const NOT_FOUND = 'Not found in the provided transcripts.';

export interface ModelAnswer {
  answer: string;
  segmentIds: string[];
}

export interface AnalysisItem {
  type: 'agreement' | 'disagreement' | 'difference';
  title: string;
  synthesis: string;
  segmentIds: string[];
}

const answerSchema = {
  type: 'object',
  properties: {
    answer: { type: 'string' },
    segmentIds: { type: 'array', items: { type: 'string' } },
  },
  required: ['answer', 'segmentIds'],
};

const analysisSchema = {
  type: 'array',
  items: {
    type: 'object',
    properties: {
      type: { type: 'string', enum: ['agreement', 'disagreement', 'difference'] },
      title: { type: 'string' },
      synthesis: { type: 'string' },
      segmentIds: { type: 'array', items: { type: 'string' } },
    },
    required: ['type', 'title', 'synthesis', 'segmentIds'],
  },
};

function evidenceBlock(segments: TranscriptSegment[]): string {
  return segments.map((segment) => [
    `SEGMENT_ID: ${segment.id}`,
    `EXPERT: ${segment.expert}`,
    `ROLE: ${segment.role}`,
    `MARKET: ${segment.market}`,
    `TIMESTAMP: ${segment.timestamp}`,
    `SPEAKER: ${segment.speaker}`,
    `TEXT: ${segment.text}`,
  ].join('\n')).join('\n\n');
}

function parseJson<T>(text: string): T {
  const cleaned = text.trim().replace(/^```json\s*/, '').replace(/\s*```$/, '');
  return JSON.parse(cleaned) as T;
}

export class GeminiProvider {
  private readonly client: GoogleGenAI;
  readonly modelName: string;

  constructor(apiKey: string, modelName = 'gemini-3.5-flash-lite') {
    this.client = new GoogleGenAI({ apiKey });
    this.modelName = modelName;
  }

  private async generate<T>(input: string, schema: object): Promise<T> {
    const interaction = await this.client.interactions.create({
      model: this.modelName,
      input,
      store: false,
      system_instruction: 'Return only valid JSON matching the supplied response schema. Use only the supplied transcript evidence.',
      response_format: { type: 'text', mime_type: 'application/json', schema },
    });
    if (!interaction.output_text) throw new Error('Gemini returned an empty interaction output.');
    return parseJson<T>(interaction.output_text);
  }

  async answer(question: string, segments: TranscriptSegment[]): Promise<ModelAnswer> {
    const input = `Answer the question using ONLY the supplied transcript evidence. Do not use outside knowledge. Use reasonable language matching: for example, ROI/economics/financial case and training/utilisation may refer to the same source concepts when the evidence supports that interpretation. For comparative questions, compare the supplied experts directly when the evidence supports a comparison. Return exactly "${NOT_FOUND}" with an empty segmentIds array only when none of the supplied evidence addresses the question. Segment IDs must be copied exactly from the evidence. Never create quotes, timestamps, experts, markets, or IDs.\n\nQUESTION: ${question}\n\nEVIDENCE:\n${evidenceBlock(segments)}`;
    return this.generate<ModelAnswer>(input, answerSchema);
  }

  async analysis(segments: TranscriptSegment[]): Promise<AnalysisItem[]> {
    const input = `Analyse only these three expert interviews. Identify useful common themes, agreements, meaningful disagreements, and market differences. Do not claim a disagreement unless the evidence shows different positions. Use "Based on these interviews" language. Every segment ID must be copied exactly from the evidence. Do not generate quote text or timestamps. Do not generalize beyond these interviews.\n\nEVIDENCE:\n${evidenceBlock(segments)}`;
    return this.generate<AnalysisItem[]>(input, analysisSchema);
  }
}

export function validateModelAnswer(answer: ModelAnswer, segments: TranscriptSegment[]): ModelAnswer {
  const validIds = new Set(segments.map((segment) => segment.id));
  const segmentIds = [...new Set(answer.segmentIds ?? [])].filter((id) => validIds.has(id));
  if (segmentIds.length === 0) return { answer: NOT_FOUND, segmentIds: [] };
  return { answer: answer.answer?.trim() || NOT_FOUND, segmentIds };
}

export function validateAnalysis(items: AnalysisItem[], segments: TranscriptSegment[]): AnalysisItem[] {
  const validIds = new Set(segments.map((segment) => segment.id));
  return (items ?? []).map((item) => ({ ...item, segmentIds: [...new Set(item.segmentIds ?? [])].filter((id) => validIds.has(id)) }))
    .filter((item) => ['agreement', 'disagreement', 'difference'].includes(item.type) && item.title && item.synthesis && item.segmentIds.length > 0);
}
