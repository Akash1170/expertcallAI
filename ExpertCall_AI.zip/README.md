# ExpertCall AI

A source-first research workspace for analysing three expert calls about the European robotic surgery market. The application is designed for a technical interview demo where accuracy, explainability and traceability matter more than flashy automation.

## What it does

- Parses the three supplied transcripts into timestamped speaker segments.
- Compares every interview-guide question across France, Germany and the United Kingdom.
- Shows cross-expert agreements and differences with supporting source evidence.
- Provides a grounded Q&A view across all calls.
- Validates every displayed quotation against the original segment before rendering it.
- Includes an evaluation script covering all six guide questions.

## Run locally

Requires Node.js 20+.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. The demo does not require an API key: the default provider uses a transparent local lexical index, which makes the evidence chain easy to inspect during an interview.

Other commands:

```bash
npm test
npm run evaluate
npm run build
```

Copy `.env.example` to `.env` when configuring a hosted model provider. No secret is read by the browser demo today; a production provider should be called from a server-side route.

## Architecture

```mermaid
flowchart LR
  A[Transcript files] --> B[Parser]
  B --> C[Timestamped segments + metadata]
  C --> D[Local retrieval index]
  D --> E[Guide / cross-expert / Ask AI]
  E --> F[Quote validator]
  F --> G[Answer + source citations]
```

The source-of-truth data is in `src/data/transcripts.ts`. `src/lib/parser.ts` owns ingestion, `src/lib/retrieval.ts` owns retrieval, `src/lib/citations.ts` owns exact quote validation, and `src/lib/llm.ts` defines the provider abstraction. The local provider is intentionally deterministic and low-risk for this short case study.

## Traceability and hallucination reduction

1. Evidence is retrieved before an answer is formed.
2. Every segment carries document ID, market, expert, role, speaker and timestamp.
3. Exact quotes must be substrings of their original source segment.
4. Citations are created only from retrieved segments.
5. Low-relevance questions return `Not found in the provided transcripts.`
6. The interface distinguishes source evidence from cross-transcript synthesis and says “Based on these interviews”.

The local index is lexical rather than embedding-based because there are only 26 short segments. For a production implementation, the `LlmProvider` boundary can be backed by an embedding model and a persistent vector store without changing the UI contract.

## Scaling to 30+ transcripts

A scalable ingestion job would watch a document store, parse new files asynchronously, create timestamp-aware chunks, batch embedding requests, and upsert vectors with document-level metadata. Retrieval could combine semantic and keyword search, metadata filters and reranking. A server-side provider would add caching, access controls, monitoring, prompt/version tracking and an evaluation set of known questions. The current modules keep those boundaries clear without adding infrastructure that the three-call demo does not need.

## Limitations

- The demo ships the provided transcript text as typed source data rather than accepting uploads.
- Local retrieval is lexical and does not replace a production embedding model.
- The generated local response is conservative by design; evidence cards are the authoritative output.
- Claims describe these three interviews only and should not be generalized to whole national markets.
