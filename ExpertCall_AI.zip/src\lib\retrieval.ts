import type { TranscriptSegment } from '../types';

const stopWords = new Set('the a an and or of to in is are it this that for on with from but how what where which do does will would can could has have be by into about over under across'.split(' '));
const tokens = (value: string) => value.toLowerCase().replace(/[^a-z0-9%]+/g, ' ').split(/\s+/).filter((token) => token.length > 2 && !stopWords.has(token));

export function retrieve(question: string, segments: TranscriptSegment[], limit = 8): TranscriptSegment[] {
  const queryTerms = tokens(question);
  const scored = segments.filter((segment) => segment.speaker !== 'Interviewer').map((segment) => {
    const textTerms = tokens(`${segment.text} ${segment.speaker} ${segment.market}`);
    const score = queryTerms.reduce((total, term) => total + (textTerms.includes(term) ? 1 : 0), 0);
    return { segment, score };
  }).filter(({ score }) => score > 0).sort((left, right) => right.score - left.score);
  return scored.slice(0, limit).map(({ segment }) => segment);
}

export function relevance(question: string, segments: TranscriptSegment[]): number {
  const queryTerms = tokens(question);
  if (queryTerms.length === 0 || segments.length === 0) return 0;
  const matched = new Set(segments.flatMap((segment) => tokens(segment.text)));
  return queryTerms.filter((term) => matched.has(term)).length / queryTerms.length;
}
