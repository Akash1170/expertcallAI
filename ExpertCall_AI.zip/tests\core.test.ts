import { describe, expect, it } from 'vitest';
import { transcripts } from '../src/data/transcripts';
import { citationFromSegment, verifyQuote } from '../src/lib/citations';
import { localGroundedProvider } from '../src/lib/llm';
import { parseAll, parseTranscript } from '../src/lib/parser';
import { retrieve } from '../src/lib/retrieval';

describe('transcript ingestion', () => {
  it('parses timestamp, speaker, text and metadata', () => {
    const segments = parseTranscript(transcripts[0]);
    expect(segments).toHaveLength(14);
    expect(segments[1]).toMatchObject({ timestamp: '00:18', speaker: 'Dr. Martin', market: 'France', expert: 'Dr. Jean Martin' });
    expect(segments[1].seconds).toBe(18);
  });
  it('preserves all source documents', () => expect(parseAll(transcripts)).toHaveLength(42));
});

describe('citation verification', () => {
  const segment = parseTranscript(transcripts[0])[1];
  it('accepts only verbatim source text', () => {
    expect(verifyQuote('Adoption is growing', segment)).toBe(true);
    expect(verifyQuote('Adoption is shrinking', segment)).toBe(false);
    expect(citationFromSegment({ text: 'source', id: 'x', documentId: 'x', expert: 'x', role: 'x', market: 'France', timestamp: '00:00', seconds: 0, speaker: 'x' }, 'invented')).toBe(null);
  });
});

describe('grounded retrieval', () => {
  const segments = parseAll(transcripts);
  it('retrieves evidence for a supported question', () => expect(retrieve('What are the main barriers and training requirements?', segments).length).toBeGreaterThan(0));
  it('returns no answer for unsupported content', () => {
    const answer = localGroundedProvider.answer('What do experts say about reimbursement taxation policy?', segments);
    expect(answer.answer).toBe('Not found in the provided transcripts.');
    expect(answer.citations).toHaveLength(0);
  });
});
