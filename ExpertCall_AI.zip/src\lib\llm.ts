import type { Citation, GroundedAnswer, TranscriptSegment } from '../types';
import { citationFromSegment } from './citations';
import { relevance, retrieve } from './retrieval';

export interface LlmProvider {
  answer(question: string, segments: TranscriptSegment[]): GroundedAnswer;
}

function selectQuote(segment: TranscriptSegment): Citation | null {
  return citationFromSegment(segment);
}

export const localGroundedProvider: LlmProvider = {
  answer(question, segments) {
    const evidence = retrieve(question, segments);
    const score = relevance(question, evidence);
    if (score < 0.25 || evidence.length === 0) return { answer: 'Not found in the provided transcripts.', citations: [], confidence: 'none', retrievedCount: 0 };
    const citations = evidence.slice(0, 4).map(selectQuote).filter((citation): citation is Citation => citation !== null);
    const markets = [...new Set(citations.map((citation) => citation.market))];
    const answer = markets.length > 1
      ? `Based on these interviews, ${markets.join(', ')} provide evidence relevant to this question. The retrieved statements are shown below so the synthesis can be checked directly against the source.`
      : `The ${markets[0]} interview provides relevant evidence for this question. The source statement is shown below for verification.`;
    return { answer, citations, confidence: score > 0.6 ? 'high' : 'medium', retrievedCount: evidence.length };
  },
};
