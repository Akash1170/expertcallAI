import { guideQuestions } from '../src/data/guide';
import { transcripts } from '../src/data/transcripts';
import { citationFromSegment } from '../src/lib/citations';
import { parseAll } from '../src/lib/parser';
import { retrieve } from '../src/lib/retrieval';

const segments = parseAll(transcripts);
console.log('ExpertCall AI evaluation');
console.log('========================');
for (const question of guideQuestions) {
  console.log(`\n${question}`);
  for (const transcript of transcripts) {
    const evidence = retrieve(question, segments.filter((segment) => segment.documentId === transcript.id), 2);
    const citation = evidence.map((segment) => citationFromSegment(segment)).find(Boolean);
    console.log(`${transcript.market}: answer generated=${evidence.length > 0} | evidence retrieved=${evidence.length} | quote valid=${Boolean(citation)} | timestamp valid=${Boolean(citation?.timestamp)} | source valid=${Boolean(citation?.source)}`);
  }
}
